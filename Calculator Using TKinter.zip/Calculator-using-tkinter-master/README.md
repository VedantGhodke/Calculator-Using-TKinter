# Calculator-using-tkinter
Run command:
#### python calculator.py

Refer temp.py file for actual working code.

![Output](https://github.com/vinaysomawat/Calculator-using-tkinter/blob/master/calculator.png)
